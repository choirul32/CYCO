<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MateriBK extends Model
{
    protected $table = 'materi_bk';
    protected $guarded = ['id']; 
}
