<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KehadiranPoint extends Model
{
    protected $table = 'users';
}
