<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Other\Kelas;
use App\Models\Other\Jurusan;
use App\Models\Other\Agama;
use Faker\Generator as Faker;

$factory->define(Kelas::class, function (Faker $faker) {
    return [
        
    ];
});

$factory->define(Jurusan::class, function (Faker $faker) {
    return [
        //
    ];
});

$factory->define(Agama::class, function (Faker $faker) {
    return [
        //
    ];
});
