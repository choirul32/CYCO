/*
Template Name: Xoric - Responsive Bootstrap 4 Admin Dashboard
Author: Themesdesign
Version: 1.0.0
Website: https://themesdesign.in/
File: Form-mask Js File
*/

$(document).ready(function(){
    $(".input-mask").inputmask();
});